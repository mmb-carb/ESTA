
__title__ = 'esta'
__version__ = '0.5.0'
__license__ = 'GPLv3'
__credits__ = ['Maybelline Disuanco', 'Leo Ramirez', 'John Stilley', 'Cheryl Taylor']


if __name__ == '__main__':
    print(__version__)
